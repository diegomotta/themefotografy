<?php
load_theme_textdomain( 'photography-translation', get_template_directory().'/languages' );
?>